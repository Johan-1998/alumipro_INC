package com.alumipro.web.controller;

import com.alumipro.service.ClienteService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controlador MVC para consultas de Clientes.
 * Renderiza vistas Thymeleaf consumiendo la capa de servicio.
 */
@Controller
public class ClienteController {

    private final ClienteService clienteService;

    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/clientes")
    public String listarClientes(Model model) {
        model.addAttribute("clientes", clienteService.listar());
        return "clientes/lista";
    }
}