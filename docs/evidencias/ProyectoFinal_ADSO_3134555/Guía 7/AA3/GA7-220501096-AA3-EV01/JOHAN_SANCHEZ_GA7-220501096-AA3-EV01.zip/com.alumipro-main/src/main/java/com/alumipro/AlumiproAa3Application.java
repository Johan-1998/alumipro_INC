package com.alumipro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada de la aplicación Spring Boot
 * Inicia el contenedor Spring, configura beans y levanta el servidor embebido.
 */
@SpringBootApplication
public class AlumiproAa3Application {
    public static void main(String[] args) {
        SpringApplication.run(AlumiproAa3Application.class, args);
    }
}