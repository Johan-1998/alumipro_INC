package com.alumipro.repository;

import com.alumipro.domain.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio Spring Data JPA para acceso a datos de clientes
 * Permite CRUD sin escribir SQL manual con framework aplicado
 */
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
}