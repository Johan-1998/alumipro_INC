package com.alumipro.repository;

import com.alumipro.domain.entity.DetalleVenta;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio Spring Data JPA para el detalle de ventas.
 */
public interface DetalleVentaRepository extends JpaRepository<DetalleVenta, Integer> {
}