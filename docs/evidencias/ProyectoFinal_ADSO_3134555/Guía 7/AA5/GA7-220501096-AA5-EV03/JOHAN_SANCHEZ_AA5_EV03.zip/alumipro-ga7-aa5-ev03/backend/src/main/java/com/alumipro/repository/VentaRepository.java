package com.alumipro.repository;

import com.alumipro.domain.entity.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio Spring Data JPA para la cabecera de ventas.
 */
public interface VentaRepository extends JpaRepository<Venta, Integer> {
}