# AA5-EV03 – Ejecución y validación (Windows + XAMPP)

## 1) Base de datos (XAMPP)
1. Abrir **XAMPP Control Panel**
2. En **MySQL** → **Start**
3. Abrir **phpMyAdmin**
4. Crear base de datos: `alumipro_db`
5. Importar en orden:
   - `db/schema.sql`
   - `db/seed.sql`

> Configuración usada: MySQL `localhost:3306`, usuario `root`, sin contraseña.

## 2) Backend (Spring Boot)
Requisitos: Java 17+, Maven.

En PowerShell:
```powershell
cd <ruta>\alumipro-ga7-aa5-ev03\backend
mvn spring-boot:run
```

Verificación rápida:
- `http://localhost:8080/api/productos` debe devolver JSON.

## 3) Validación de regla de stock (sin negativos)

### Caso OK (descuenta stock)
1. Consultar stock:
   - GET `http://localhost:8080/api/productos/2`
2. Registrar venta:
   - POST `http://localhost:8080/api/ventas`
   - Body:
     ```json
     { "clienteId": 1, "items": [ { "productoId": 2, "cantidad": 1 } ] }
     ```
3. Volver a consultar producto 2:
   - El stock debe disminuir en 1.

### Caso ERROR (no permite stock negativo)
1. POST `http://localhost:8080/api/ventas` con cantidad mayor al stock:
   ```json
   { "clienteId": 1, "items": [ { "productoId": 2, "cantidad": 999999 } ] }
   ```
2. Debe responder 400 con mensaje **Stock insuficiente** y NO debe haber cambios en la BD.

## 4) Validación con Postman
Importar la colección:
- `docs/postman_collection.json`

Ejecutar en orden:
1. Productos - Listar
2. Clientes - Listar
3. Ventas - Crear (descuenta stock)
4. Ventas - Crear (stock insuficiente)
