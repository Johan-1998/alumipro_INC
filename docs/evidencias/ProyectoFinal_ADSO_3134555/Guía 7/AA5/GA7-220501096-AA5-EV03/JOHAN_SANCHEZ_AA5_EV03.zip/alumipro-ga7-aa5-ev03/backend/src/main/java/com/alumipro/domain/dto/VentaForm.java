package com.alumipro.domain.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * DTO de formulario para capturar los datos de una venta desde la vista Thymeleaf
 * Evita acoplar directamente el formulario a las entidades JPA
 */

public class VentaForm {

    private Integer clienteId;

    private List<ItemVentaForm> items = new ArrayList<>();

    public VentaForm() {
        items.add(new ItemVentaForm());
        items.add(new ItemVentaForm());
    }

    public Integer getClienteId() { return clienteId; }
    public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }

    public List<ItemVentaForm> getItems() { return items; }
    public void setItems(List<ItemVentaForm> items) { this.items = items; }
}