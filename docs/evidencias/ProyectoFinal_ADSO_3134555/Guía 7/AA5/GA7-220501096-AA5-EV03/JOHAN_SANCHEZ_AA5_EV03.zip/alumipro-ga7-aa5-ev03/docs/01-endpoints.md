# AA5-EV03 – Documentación de servicios web (Alumipro)

Base URL: `http://localhost:8080`

## Convenciones
- Todas las rutas inician con `/api`.
- Formato de respuesta: JSON.
- Códigos HTTP usados:
  - 200 OK (consultas y actualizaciones)
  - 201 Created (creación)
  - 204 No Content (eliminación)
  - 400 Bad Request (validaciones / regla de negocio)
  - 500 Internal Server Error (errores no controlados)

---

## Productos

### GET `/api/productos`
Lista todos los productos.

**200 OK**: `[{ id, nombre, precio, stock, descripcion }]`

### GET `/api/productos/{id}`
Obtiene un producto por id.

**200 OK**: `{ id, nombre, precio, stock, descripcion }`

### POST `/api/productos`
Crea un producto.

Body ejemplo:
```json
{
  "nombre": "Aluminio perfil 2m",
  "precio": 98000,
  "stock": 10,
  "descripcion": "Perfil aluminio para ventaneria"
}
```

**201 Created**: producto creado.

### PUT `/api/productos/{id}`
Actualiza un producto.

**200 OK**: producto actualizado.

### DELETE `/api/productos/{id}`
Elimina un producto.

**204 No Content**

---

## Clientes

### GET `/api/clientes`
Lista todos los clientes.

### GET `/api/clientes/{id}`
Obtiene un cliente por id.

### POST `/api/clientes`
Crea un cliente.

Body ejemplo:
```json
{
  "nombre": "Cliente Demo",
  "email": "demo@email.com",
  "direccion": "Calle 123",
  "telefono": "3000000000"
}
```

### PUT `/api/clientes/{id}`
Actualiza un cliente.

### DELETE `/api/clientes/{id}`
Elimina un cliente.

---

## Ventas

### POST `/api/ventas`
Registra una venta, guarda cabecera y detalle, y descuenta stock (sin permitir stock negativo).

Body ejemplo:
```json
{
  "clienteId": 1,
  "items": [
    { "productoId": 2, "cantidad": 1 },
    { "productoId": 3, "cantidad": 2 }
  ]
}
```

**201 Created**:
```json
{ "ventaId": 10, "total": 123000 }
```

Regla de negocio:
- Si `cantidad > stock` del producto, la venta NO se registra y se responde:

**400 Bad Request**:
```json
{
  "status": 400,
  "error": "Bad Request",
  "message": "Stock insuficiente para: <nombre>"
}
```
