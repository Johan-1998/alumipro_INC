# Alumipro – GA7-220501096-AA5-EV03 (Servicios web)

Entrega enfocada en el desarrollo y documentación de servicios web (API REST) del proyecto Alumipro.

## Contenido
- `backend/`: API REST Spring Boot
- `db/`: scripts SQL (schema y seed)
- `docs/`: documentación de endpoints, ejecución y colección Postman

## Ejecutar
Ver `docs/02-ejecucion.md`.
