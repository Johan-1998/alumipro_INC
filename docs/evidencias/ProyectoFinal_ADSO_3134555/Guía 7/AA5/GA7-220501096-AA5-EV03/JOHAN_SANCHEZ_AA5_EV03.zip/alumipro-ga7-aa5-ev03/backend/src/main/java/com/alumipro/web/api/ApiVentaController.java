package com.alumipro.web.api;

import com.alumipro.domain.dto.VentaForm;
import com.alumipro.domain.entity.Venta;
import com.alumipro.repository.VentaRepository;
import com.alumipro.service.VentaService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * API REST para registrar ventas desde el frontend React.
 */
@RestController
@RequestMapping("/api/ventas")
public class ApiVentaController {

    private final VentaService ventaService;
    private final VentaRepository ventaRepository;

    public ApiVentaController(VentaService ventaService, VentaRepository ventaRepository) {
        this.ventaService = ventaService;
        this.ventaRepository = ventaRepository;
    }

    public static class VentaCreateResponse {
        public Integer ventaId;
        public BigDecimal total;

        public VentaCreateResponse(Integer ventaId, BigDecimal total) {
            this.ventaId = ventaId;
            this.total = total;
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public VentaCreateResponse crear(@RequestBody VentaForm form) {
        Integer ventaId = ventaService.registrarVenta(form);
        Venta v = ventaRepository.findById(ventaId)
                .orElseThrow(() -> new IllegalStateException("Venta no encontrada después de registrar: " + ventaId));
        return new VentaCreateResponse(v.getId(), v.getTotal());
    }
}
