package com.alumipro.service;

import com.alumipro.domain.dto.ItemVentaForm;
import com.alumipro.domain.dto.VentaForm;
import com.alumipro.domain.entity.Cliente;
import com.alumipro.domain.entity.DetalleVenta;
import com.alumipro.domain.entity.Producto;
import com.alumipro.domain.entity.Venta;
import com.alumipro.repository.ClienteRepository;
import com.alumipro.repository.DetalleVentaRepository;
import com.alumipro.repository.ProductoRepository;
import com.alumipro.repository.VentaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Servicio de negocio para el registro de ventas.
 * Responsabilidades:
 * - Validar datos de entrada de cliente, productos y cantidades
 * - Ejecutar la transacción completa: ventas más detalle_venta y más descuento de stock.
 * - Garantizar consistencia: si falla algo, se revierte toda la operación con rollback.
 */

@Service
public class VentaService {

    private final VentaRepository ventaRepository;
    private final DetalleVentaRepository detalleVentaRepository;
    private final ProductoRepository productoRepository;
    private final ClienteRepository clienteRepository;

    public VentaService(
            VentaRepository ventaRepository,
            DetalleVentaRepository detalleVentaRepository,
            ProductoRepository productoRepository,
            ClienteRepository clienteRepository
    ) {
        this.ventaRepository = ventaRepository;
        this.detalleVentaRepository = detalleVentaRepository;
        this.productoRepository = productoRepository;
        this.clienteRepository = clienteRepository;
    }

    /**
     * Registra una venta de forma atómica.
     * Se usa @Transactional para garantizar:
     * - Commit si toda la operación es exitosa.
     * - Rollback automático si ocurre cualquier RuntimeException,
     *   evitando ventas parciales, detalles parciales o stock descontado incorrectamente.
     *
     * @param form datos capturados en el formulario de cliente más ítems de productos
     * @return id de la venta generada.
     */

    @Transactional
    public Integer registrarVenta(VentaForm form) {
        if (form.getClienteId() == null) {
            throw new IllegalArgumentException("Debe seleccionar un cliente.");
        }

        Cliente cliente = clienteRepository.findById(form.getClienteId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado: " + form.getClienteId()));

        Venta venta = new Venta();
        venta.setFecha(LocalDate.now());
        venta.setCliente(cliente);
        venta.setTotal(BigDecimal.ZERO);

        // Se guarda primero la cabecera para obtener el ID de la venta y poder asociar los detalles.
        venta = ventaRepository.save(venta);

        BigDecimal total = BigDecimal.ZERO;

        // Se recorren los ítems del formulario. Se permite que algunas filas vengan vacías,
        // pero si un ítem tiene producto o cantidad, se valida y se procesa completamente
        for (ItemVentaForm item : form.getItems()) {
            if (item.getProductoId() == null && item.getCantidad() == null) {
                continue; // fila vacía
            }
            if (item.getProductoId() == null) {
                throw new IllegalArgumentException("Producto es obligatorio en cada ítem.");
            }
            if (item.getCantidad() == null || item.getCantidad() <= 0) {
                throw new IllegalArgumentException("Cantidad debe ser > 0.");
            }

            Producto producto = productoRepository.findById(item.getProductoId())
                    .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado: " + item.getProductoId()));

            // Descuento atómico: si retorna 0, no hay stock suficiente en tiempo real
            int actualizado = productoRepository.descontarStockSiDisponible(producto.getId(), item.getCantidad());
            if (actualizado == 0) {
                throw new IllegalArgumentException("Stock insuficiente para: " + producto.getNombre());
            }

            BigDecimal subtotal = producto.getPrecio().multiply(BigDecimal.valueOf(item.getCantidad()));

            DetalleVenta dv = new DetalleVenta();
            dv.setVenta(venta);
            dv.setProducto(producto);
            dv.setCantidad(item.getCantidad());
            dv.setSubtotal(subtotal);
            // Se registra el detalle de la venta con el subtotal calculado en base al precio actual del producto
            detalleVentaRepository.save(dv);

            total = total.add(subtotal);
        }

        if (total.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Debe ingresar al menos un producto válido.");
        }

        // Se actualiza el total final en la cabecera después de procesar todos los ítems
        venta.setTotal(total);
        ventaRepository.save(venta);

        return venta.getId();
    }
}