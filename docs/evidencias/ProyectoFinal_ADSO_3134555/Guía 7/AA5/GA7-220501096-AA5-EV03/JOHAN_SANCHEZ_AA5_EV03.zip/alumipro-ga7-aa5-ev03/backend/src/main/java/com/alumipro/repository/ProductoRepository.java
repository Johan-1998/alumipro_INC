package com.alumipro.repository;

import com.alumipro.domain.entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    /**
     * Descuenta stock de forma segura y concurrente
     * Retorna:
     * - 1 si se descontó correctamente el stock es suficiente
     * - 0 si no se descontó el stock es insuficiente
     *
     * Esto evita inconsistencias por múltiples ventas simultáneas.
     */
    @Modifying
    @Query("UPDATE Producto p SET p.stock = p.stock - :cantidad WHERE p.id = :id AND p.stock >= :cantidad")
    int descontarStockSiDisponible(@Param("id") Integer id, @Param("cantidad") Integer cantidad);
}
