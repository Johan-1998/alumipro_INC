package com.alumipro.service;

import com.alumipro.domain.entity.Cliente;
import com.alumipro.repository.ClienteRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio de negocio para Clientes.
 * Expone operaciones de lectura y luego CRUD si se requiere.
 */
@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public ClienteService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    public List<Cliente> listar() {
        return clienteRepository.findAll();
    }
}