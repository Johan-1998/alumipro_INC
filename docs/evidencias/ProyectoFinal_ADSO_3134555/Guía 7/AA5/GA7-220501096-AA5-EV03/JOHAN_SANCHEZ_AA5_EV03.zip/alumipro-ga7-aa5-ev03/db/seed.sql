USE alumipro_db;

-- Datos de ejemplo (puedes modificarlos o borrarlos)
INSERT INTO clientes (nombre, telefono, email) VALUES
  ('Cliente Demo 1', '3000000001', 'demo1@correo.com'),
  ('Cliente Demo 2', '3000000002', 'demo2@correo.com')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);

INSERT INTO productos (nombre, precio, stock, descripcion) VALUES
  ('Producto A', 10000.00, 50, 'Producto de ejemplo A'),
  ('Producto B', 25000.00, 20, 'Producto de ejemplo B'),
  ('Producto C', 5000.00, 100, 'Producto de ejemplo C')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);
