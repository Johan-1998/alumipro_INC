package com.alumipro.web.controller;

import com.alumipro.domain.dto.VentaForm;
import com.alumipro.repository.ClienteRepository;
import com.alumipro.repository.ProductoRepository;
import com.alumipro.service.VentaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Controlador MVC para el flujo de ventas.
 * Responsabilidad:
 * - Renderizar el formulario GET
 * - Recibir el envío del formulario POST
 * - Mostrar resultado o errores de validación de negocio
 */
@Controller
@RequestMapping("/ventas")
public class VentaController {

    private final ClienteRepository clienteRepository;
    private final ProductoRepository productoRepository;
    private final VentaService ventaService;

    public VentaController(ClienteRepository clienteRepository,
                           ProductoRepository productoRepository,
                           VentaService ventaService) {
        this.clienteRepository = clienteRepository;
        this.productoRepository = productoRepository;
        this.ventaService = ventaService;
    }

    @GetMapping("/nueva")
    public String formNueva(Model model) {

        // Carga catálogos necesarios para el formulario: clientes y productos disponibles
        model.addAttribute("clientes", clienteRepository.findAll());
        model.addAttribute("productos", productoRepository.findAll());
        model.addAttribute("ventaForm", new VentaForm());
        return "ventas/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("ventaForm") VentaForm ventaForm, Model model) {
        try {

            // Delego la transacción completa al servicio para mantener el controlador liviano
            // y centralizar la lógica de negocio en una sola capa
            Integer ventaId = ventaService.registrarVenta(ventaForm);
            model.addAttribute("ventaId", ventaId);
            return "ventas/resultado";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("clientes", clienteRepository.findAll());
            model.addAttribute("productos", productoRepository.findAll());
            model.addAttribute("error", ex.getMessage());
            return "ventas/form";
        }
    }
}
