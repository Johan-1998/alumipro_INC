package com.alumipro.web.api;

import com.alumipro.domain.entity.Cliente;
import com.alumipro.service.ClienteService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * API REST para exponer Clientes al frontend (React).
 */
@RestController
@RequestMapping("/api/clientes")
public class ApiClienteController {

    private final ClienteService clienteService;

    public ApiClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping
    public List<Cliente> listar() {
        return clienteService.listar();
    }
}
