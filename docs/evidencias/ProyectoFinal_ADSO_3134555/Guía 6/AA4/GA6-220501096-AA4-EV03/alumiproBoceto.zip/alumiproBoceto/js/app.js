// Menú accesible
const toggle = document.querySelector('.nav__toggle');
const nav = document.getElementById('menu');
toggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(isOpen));
  toggle.setAttribute('aria-label', isOpen ? 'Cerrar menú' : 'Abrir menú');
});

// mock
const productos = [
  { id: 1, nombre: 'Ventana corrediza 1.20m', precio: 380000, img: 'assets/img/prod1.webp', alt:'Ventana corrediza en aluminio color natural' },
  { id: 2, nombre: 'Puerta batiente 80cm', precio: 520000, img: 'assets/img/prod2.webp', alt:'Puerta batiente en aluminio vidrio templado' },
  { id: 3, nombre: 'Perfil L 1" x 1"', precio: 12000, img: 'assets/img/prod3.webp', alt:'Perfil en L de aluminio una pulgada' },
  { id: 4, nombre: 'Panel compuesto ACM', precio: 210000, img: 'assets/img/prod4.webp', alt:'Panel compuesto de aluminio' },
  { id: 5, nombre: 'Manija ergonómica', precio: 35000, img: 'assets/img/prod5.webp', alt:'Manija ergonómica para ventana' },
  { id: 6, nombre: 'Cierre multipunto', precio: 78000, img: 'assets/img/prod6.webp', alt:'Sistema de cierre multipunto' },
];

function currency(v){ return new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(v); }

const cont = document.getElementById('cards-contenedor');
const tpl = document.getElementById('card-template');

productos.forEach(p => {
  const node = tpl.content.cloneNode(true);
  const img = node.querySelector('.product__img');
  const title = node.querySelector('.product__title');
  const meta = node.querySelector('.product__meta');
  img.src = p.img;
  img.alt = p.alt;
  title.textContent = p.nombre;
  meta.textContent = currency(p.precio);
  node.querySelector('.add-btn').addEventListener('click', (e)=>{
    e.target.textContent = 'Añadido ✓';
    e.target.setAttribute('aria-live', 'polite');
  });
  cont.appendChild(node);
});

// Año dinámico
document.getElementById('anio').textContent = new Date().getFullYear();

// Validación con feedback
const form = document.getElementById('contacto-form');
const spinner = document.getElementById('spinner');

function setError(id, msg){
  const el = document.getElementById('error-'+id);
  el.textContent = msg || '';
}
function validEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }

form.addEventListener('submit', (e)=>{
  e.preventDefault();
  setError('nombre'); setError('email'); setError('mensaje');
  let ok = true;
  const nombre = form.nombre.value.trim();
  const email = form.email.value.trim();
  const mensaje = form.mensaje.value.trim();

  if(nombre.length < 3){ setError('nombre','Mínimo 3 caracteres.'); ok=false; }
  if(!validEmail(email)){ setError('email','Correo inválido.'); ok=false; }
  if(mensaje.length < 10){ setError('mensaje','Mínimo 10 caracteres.'); ok=false; }

  if(!ok) return;

  spinner.setAttribute('aria-hidden','false');
  setTimeout(()=>{
    spinner.setAttribute('aria-hidden','true');
    form.reset();
    alert('Mensaje enviado. ¡Gracias!');
  }, 900);
});

// Foco visible al tabular
document.addEventListener('keyup', (e)=>{
  if(e.key === 'Tab'){ document.body.classList.add('user-is-tabbing'); }
});